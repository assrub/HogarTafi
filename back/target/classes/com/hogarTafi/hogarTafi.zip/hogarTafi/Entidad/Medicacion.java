package com.hogarTafi.hogarTafi.Entidad;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "Medicacion")
public class Medicacion {
    @Id
    private Integer dni;
    private String medicamento;
    private String almuerzo;
    private String merienda;
    private String cena;
    private String horario;
    private String observaciones;
}
