package com.hogarTafi.hogarTafi.Repositorio;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import com.hogarTafi.hogarTafi.Entidad.Medicacion;

import java.util.List;
import java.util.Optional;

@Repository
public interface RepositorioMedicacion extends MongoRepository<Medicacion, Integer> {
    @Override
    List<Medicacion> findAll();

    Optional<Medicacion> findByDni(Integer dni);
}
