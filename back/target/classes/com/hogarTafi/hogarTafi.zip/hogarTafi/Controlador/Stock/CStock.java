package com.hogarTafi.hogarTafi.Controlador.Stock;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@RequestMapping("/stock")
public class CStock {

    
}
