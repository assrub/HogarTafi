package com.hogarTafi.hogarTafi.Servicio.impl;public class ServicioStockImpl {
}
