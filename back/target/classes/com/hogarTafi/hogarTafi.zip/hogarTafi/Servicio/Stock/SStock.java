package com.hogarTafi.hogarTafi.Servicio.Stock;public class SStock {
}
