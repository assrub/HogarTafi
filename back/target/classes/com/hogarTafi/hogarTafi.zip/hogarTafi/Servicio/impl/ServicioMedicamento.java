package com.hogarTafi.hogarTafi.Servicio.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hogarTafi.hogarTafi.Entidad.Medicacion;
import com.hogarTafi.hogarTafi.Repositorio.RepositorioMedicacion;
import com.hogarTafi.hogarTafi.Repositorio.RepositorioPaciente;



@Service
public class ServicioMedicamento {
    @Autowired
    private RepositorioMedicacion repositorioMedicacion;

    
    @Autowired
    private RepositorioPaciente repositorioPacientes;

    public boolean registrarMedicamento(Integer dni, String medicamento, String almuerzo, String merienda, String cena, String horario, String observaciones) {
        
        
        // Verificar si el paciente no existe
        if (!repositorioPacientes.findByDni(dni).isPresent()) {
            return false; // El paciente no esta registrado
        }

        // Crear una nueva instancia de Medicacion y establecer sus propiedades
        Medicacion medicacion = new Medicacion();
        medicacion.setDni(dni);
        medicacion.setMedicamento(medicamento);
        medicacion.setAlmuerzo(almuerzo);
        medicacion.setMerienda(merienda);
        medicacion.setCena(cena);
        medicacion.setHorario(horario);
        medicacion.setObservaciones(observaciones);
    
        // Guardar el paciente actualizado en la base de datos
        repositorioMedicacion.save(medicacion);

        return true; // Medicamento registrado con éxito
    }
    
}
