package com.hogarTafi.hogarTafi.Consulta;

public class BuscarHorarioMedicamentosPorPacienteConsulta {
}
