package com.hogarTafi.hogarTafi.Consulta;

import lombok.Data;

@Data
public class OcultarPacienteConsulta {
    private Integer dni;

    // Podrías agregar más campos si necesitas en el futuro
}
