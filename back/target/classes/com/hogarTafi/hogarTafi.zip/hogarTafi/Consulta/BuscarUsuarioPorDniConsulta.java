package com.hogarTafi.hogarTafi.Consulta;

public class BuscarUsuarioPorDniConsulta {
}
