package com.hogarTafi.hogarTafi.contraseña.servicio;

public interface RecuperarContraseñaServicio {
    boolean recuperarContraseña(String email);
}
