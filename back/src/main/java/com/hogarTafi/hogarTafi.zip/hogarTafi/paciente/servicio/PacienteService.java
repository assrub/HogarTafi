package com.hogarTafi.hogarTafi.paciente.servicio;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.hogarTafi.hogarTafi.paciente.entidad.EPaciente;
import com.hogarTafi.hogarTafi.paciente.dto.PacienteDTO;

public interface PacienteService {
    List<EPaciente> todosLosPacientes();

    boolean guardarPaciente(PacienteDTO paciente, MultipartFile fotoFrenteCarnet, MultipartFile fotoAtrasCarnet, MultipartFile fotoFrenteDni, MultipartFile fotoAtrasDni);
   
    EPaciente buscarPaciente(Integer dni);

    boolean desactivarPaciente(Integer dni);

    boolean actualizarPaciente(EPaciente PacienteDtos);

    String convertirABase64(byte[] bytes);

    List<Map<String, Object>> obtenerPacientesConFotos();
}
