package com.hogarTafi.hogarTafi.stock.controlador;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@RequestMapping("/stock")
public class CStock {

    
}
