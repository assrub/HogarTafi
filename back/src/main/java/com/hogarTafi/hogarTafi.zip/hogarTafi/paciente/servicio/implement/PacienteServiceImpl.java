package com.hogarTafi.hogarTafi.paciente.servicio.implement;

import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hogarTafi.hogarTafi.paciente.dto.PacienteDTO;
import com.hogarTafi.hogarTafi.paciente.entidad.EPaciente;
import com.hogarTafi.hogarTafi.paciente.repositorio.RPaciente;
import com.hogarTafi.hogarTafi.paciente.servicio.PacienteService;

@Service
public class PacienteServiceImpl implements PacienteService {

    @Autowired
    private RPaciente repositorioPacientes;
    
    @Override
    public List<EPaciente> todosLosPacientes() {
        return repositorioPacientes.findAll();
    }

    @Override
    public boolean guardarPaciente(PacienteDTO PacienteDtos, MultipartFile fotoFrenteCarnet, MultipartFile fotoAtrasCarnet, MultipartFile fotoFrenteDni, MultipartFile fotoAtrasDni) {
       
        try {
            EPaciente paciente = new EPaciente();
            
            paciente.setDni(PacienteDtos.getDni());
            paciente.setNombre(PacienteDtos.getNombre());
            paciente.setApellido(PacienteDtos.getApellido());
            paciente.setObraSocial(PacienteDtos.getObraSocial());
            paciente.setObservaciones(PacienteDtos.getObservaciones());
    
            
            // Convertir archivos MultipartFile a byte[] si no están vacíos
            if (fotoFrenteCarnet != null && !fotoFrenteCarnet.isEmpty()) {
                paciente.setFotoFrenteCarnet(fotoFrenteCarnet.getBytes());
            }
            if (fotoAtrasCarnet!= null &&!fotoAtrasCarnet.isEmpty()) {
                paciente.setFotoAtrasCarnet(fotoAtrasCarnet.getBytes());
            }
            if (fotoFrenteDni!= null &&!fotoFrenteDni.isEmpty()) {
                paciente.setFotoFrenteDni(fotoFrenteDni.getBytes());
            }
            if (fotoAtrasDni!= null &&!fotoAtrasDni.isEmpty()) {
                paciente.setFotoAtrasDni(fotoAtrasDni.getBytes());
            }

            // Verificar si el paciente ya existe
            if (repositorioPacientes.findByDni(paciente.getDni()).isPresent()) {
                return false; 
            }

            // Guardar el paciente en la base de datos
            repositorioPacientes.save(paciente);
            return true; // Paciente registrado con éxito
            
        } catch (Exception e) {
            return false; 
        }
    }

    @Override
    public EPaciente buscarPaciente(Integer dni) {
        return repositorioPacientes.findByDni(dni).orElseThrow(() -> new NoSuchElementException("Paciente con el DNI " + dni + " no se encontró."));
    }

    public boolean actualizarPaciente(EPaciente PacienteDtos) 
    {
        // Obtener el paciente existente
        EPaciente paciente = repositorioPacientes.findByDni(PacienteDtos.getDni()).orElseThrow(() -> new NoSuchElementException("Paciente no encontrado."));
       
        // Actualizar solo los campos proporcionados
        if (PacienteDtos.getNombre() != null) paciente.setNombre(PacienteDtos.getNombre());
        if (PacienteDtos.getApellido() != null) paciente.setApellido(PacienteDtos.getApellido());
        if (PacienteDtos.getObraSocial() != null) paciente.setObraSocial(PacienteDtos.getObraSocial());
        if (PacienteDtos.getObservaciones() != null) paciente.setObservaciones(PacienteDtos.getObservaciones());

        if (PacienteDtos.getFotoFrenteCarnet() != null) paciente.setFotoFrenteCarnet(PacienteDtos.getFotoFrenteCarnet());
        if (PacienteDtos.getFotoAtrasCarnet() != null) paciente.setFotoAtrasCarnet(PacienteDtos.getFotoAtrasCarnet());
        if (PacienteDtos.getFotoFrenteDni() != null) paciente.setFotoFrenteDni(PacienteDtos.getFotoFrenteDni());
        if (PacienteDtos.getFotoAtrasDni() != null) paciente.setFotoAtrasDni(PacienteDtos.getFotoAtrasDni());

        // Guardar los cambios
        repositorioPacientes.save(paciente);

        // Devolver verdadero si el paciente fue modificado correctamente
        return true;
    }

    @Override
    public boolean desactivarPaciente(Integer dni) {
        
        EPaciente existePaciente = buscarPaciente(dni);

        // Verificar si el paciente ya está oculto
        if (!existePaciente.getActivo()) {
            throw new IllegalArgumentException("El paciente ya está oculto.");
        }

        // Si el paciente está activo, se desactiva
        existePaciente.setActivo(false);
        repositorioPacientes.save(existePaciente);
        return true;
    }

    public String convertirABase64(byte[] bytes) {
        return Base64.getEncoder().encodeToString(bytes);
    }

    @Override
    public List<Map<String, Object>> obtenerPacientesConFotos() {
        List<EPaciente> pacientes = repositorioPacientes.findAll();
        return pacientes.stream().map(paciente -> {
            Map<String, Object> pacienteMap = new HashMap<>();
            if (paciente.getActivo()) {
                pacienteMap.put("dni", paciente.getDni());
                pacienteMap.put("nombre", paciente.getNombre());
                pacienteMap.put("apellido", paciente.getApellido());
                pacienteMap.put("obraSocial", paciente.getObraSocial());
                pacienteMap.put("observaciones", paciente.getObservaciones());

                // Convertir fotos de binario a base64
                if (paciente.getFotoFrenteCarnet() != null) {
                    pacienteMap.put("fotoFrenteCarnet", convertirABase64(paciente.getFotoFrenteCarnet()));
                }
                if (paciente.getFotoAtrasCarnet() != null) {
                    pacienteMap.put("fotoAtrasCarnet", convertirABase64(paciente.getFotoAtrasCarnet()));
                }
                if (paciente.getFotoAtrasDni() != null) {
                    pacienteMap.put("fotoAtrasDni", convertirABase64(paciente.getFotoAtrasDni()));
                }
                if (paciente.getFotoFrenteDni() != null) {
                    pacienteMap.put("fotoFrenteDni", convertirABase64(paciente.getFotoFrenteDni()));
                }

            }
            return pacienteMap;
        }).collect(Collectors.toList());
    }

}
