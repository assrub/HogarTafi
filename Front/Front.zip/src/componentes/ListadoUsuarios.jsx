import React from "react";

export default function ListadoUsuarios(){

    return (
        <div>
        <div className="titulo flex justify-center text-xl lg:text-3xl lg:mt-5 mb-10 ">
        <h2 className="font-bold">Listado de usuarios</h2>
      </div>

      
        </div>

    );
}