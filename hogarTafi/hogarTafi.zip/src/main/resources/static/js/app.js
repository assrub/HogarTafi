//recupero el elemento que quiero
const boton = document.querySelector('button');

//Evento click
/*boton.addEventListener('click', function() {

    //Id del atributo del HTML
    const id = this.getAttribute('data-id');
    
    if( this.classList.contains('liked')){
        this.classList.remove('liked');
        this.innerText = 'Me gusta';
    }else{
        this.classList.add('liked');
        this.innerText = 'Ya no me gusta'
    }
    
})*/